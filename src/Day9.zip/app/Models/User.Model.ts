export class repos {
 id:string='';
 name:string='';
 html_url:string='';
 description:string='';

}

export class user {
    id:string='';
    name:string='';
    type:string='';
}