import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
name='Archana';
num=0;
clickCount:number=0;
  constructor() { }

  ngOnInit(): void {
    
  }
 
}
