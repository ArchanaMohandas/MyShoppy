import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { LoginComponent } from './Login/login.component';
import { RegisterComponent } from './register/register.component';
import { MainComponent } from './main/main.component';
import { FooterComponent } from './footer/footer.component';
import { HomeBannerComponent } from './home-banner/home-banner.component';
import { ProductsComponent } from './products/products.component';
import { FormsModule } from '@angular/forms';
import { addClassDirective } from './CustomDirectives/addClass.directive';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    HeaderComponent,
    LoginComponent,
    MainComponent,
    FooterComponent,
    HomeBannerComponent,
    ProductsComponent,
    addClassDirective
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
