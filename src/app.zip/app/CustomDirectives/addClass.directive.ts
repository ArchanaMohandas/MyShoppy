import { Directive, ElementRef, Input, OnInit, Renderer2 } from "@angular/core";


@Directive({
    selector:'[mystyle]'
})

export class addClassDirective implements OnInit{

@Input() classname:string='';
constructor(private ele:ElementRef,private rendered:Renderer2)
{}

 ngOnInit()
 {
    
this.rendered.setAttribute(this.ele.nativeElement,'classname',this.classname);
        
    }
}
 