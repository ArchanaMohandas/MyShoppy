import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HeaderComponent } from './Components/header/header.component';
import { LoginComponent } from './Components/Login/login.component';
import { RegisterComponent } from './Components/register/register.component';
import { MainComponent } from './Components/main/main.component';
import { FooterComponent } from './Components/footer/footer.component';
import { HomeBannerComponent } from './Components/home-banner/home-banner.component';
import { ProductsComponent } from './Components/products/products.component';
import { FormsModule } from '@angular/forms';
import {  mystyleDirective } from './CustomDirectives/addClass.directive';
import { customColorDirective } from './CustomDirectives/color.directive';
import { StyleDirective } from './CustomDirectives/style.directive';
import { MyCustomPipe } from './Pipes/my-custom.pipe';
import { ViewUserDataComponent } from './Components/view-user-data/view-user-data.component';
import { LoggerService } from './Services/Logger.service';
import { UserService } from './Services/user.service';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    HeaderComponent,
    LoginComponent,
    MainComponent,
    FooterComponent,
    HomeBannerComponent,
    ProductsComponent,
mystyleDirective,
customColorDirective,
StyleDirective,
MyCustomPipe,
ViewUserDataComponent  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [LoggerService,UserService],
  bootstrap: [AppComponent]
})
export class AppModule { }
