import { Component, Input, OnInit } from '@angular/core';
import { UserService } from 'src/app/Services/user.service';

@Component({
  selector: 'app-view-user-data',
  templateUrl: './view-user-data.component.html',
  styleUrls: ['./view-user-data.component.css'],
  providers:[UserService]
})
export class ViewUserDataComponent implements OnInit {

@Input()  user:any;
  constructor(private userService:UserService) { }

  ngOnInit(): void {
  }

}
