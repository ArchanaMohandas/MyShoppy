import { style } from "@angular/animations";
import { Component } from "@angular/core";

@Component({
    selector:'login',
    templateUrl:'./login.component.html'
    
})
export class LoginComponent{

    loginSuccess:boolean=true;
    loginFailure:boolean=true;
    userlist=[
        {
            username:"admin",
            password:"admin"
        },
        {
            username:"archana",
            password:"test1234"
        },
        {
            username:"sid",
            password:"sid23"
        }
    ]

username:string='';
password:string='';

Login()
{
  for(let u of this.userlist)
  {
      if(u.username==this.username && u.password==this.password)
      {
 this.loginSuccess==false
          //alert("Login successful");
      }
      else
      {
          this.username='';
          this.password='';
          alert("login failed");
      }
  }
}

}

