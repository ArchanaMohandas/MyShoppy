import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HeaderComponent } from './Components/header/header.component';
import { LoginComponent } from './Components/Login/login.component';
import { RegisterComponent } from './Components/register/register.component';
import { MainComponent } from './Components/main/main.component';
import { FooterComponent } from './Components/footer/footer.component';
import { HomeBannerComponent } from './Components/home-banner/home-banner.component';
import { ProductsComponent } from './Components/products/products.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {  mystyleDirective } from './CustomDirectives/addClass.directive';
import { customColorDirective } from './CustomDirectives/color.directive';
import { StyleDirective } from './CustomDirectives/style.directive';
import { MyCustomPipe } from './Pipes/my-custom.pipe';
import { ViewUserDataComponent } from './Components/view-user-data/view-user-data.component';
import { LoggerService } from './Services/Logger.service';
import { UserService } from './Services/user.service';
import { ReactiveFormComponent } from './Components/reactive-form/reactive-form.component';
import { CustomerComponent } from './Components/customer/customer.component';
import {AuthGuardService} from './auth-guard.service';

import {RouterModule} from '@angular/router';
import { ErrorComponent } from './components/error/error.component';
@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    HeaderComponent,
    LoginComponent,
    MainComponent,
    FooterComponent,
    HomeBannerComponent,
    ProductsComponent,
mystyleDirective,
customColorDirective,
StyleDirective,
MyCustomPipe,
ViewUserDataComponent,
ReactiveFormComponent,
CustomerComponent,
ErrorComponent  ],

  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forRoot([
      {path:'login',component:LoginComponent},
      {path:'register',component:RegisterComponent},
      {path:'products',component:ProductsComponent},
      {path:'customer',component:CustomerComponent,canActivate:[AuthGuardService]},
      {path:'main',component:MainComponent,canActivate:[AuthGuardService]},
      {path:'view/:username',component:ViewUserDataComponent,canActivate:[AuthGuardService]},
      {path:'',redirectTo:'login',pathMatch:'full'},
      {path:'**',component:ErrorComponent}

      ]  )
  
  ],
  providers: [LoggerService,UserService,AuthGuardService],
  bootstrap: [AppComponent]
})
export class AppModule { }
